# FastAPI Auth Project

## Instruções de Execução

1. Clone o repositório.
2. Navegue até o diretório do projeto.
3. Execute `docker build -t fastapi_auth_project .` para construir a imagem.
4. Execute `docker run -d -p 8000:8000 fastapi_auth_project` para iniciar o container.
5. Acesse a API em `http://localhost:8000`.